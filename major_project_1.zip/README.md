This project is entirely made with Express.js.

Before executing any command first install all the dependencies of the project by.

```bash
npm install
```

To start the dev server run the below command

```bash
npm run dev
```

To run start the production server run:

```bash
npm start
```

This project expects a few env variables. Please provide proper env variables if the server shows any error.
